package eu.tilsner.cubansea.search.yahooboss;

import java.util.List;

import eu.tilsner.cubansea.search.SearchResult;

public class Search implements eu.tilsner.cubansea.search.Search {

	private static final String APP_ID = "LO2BOCXV34F.U.IpUsw7A0Pg4B6dAsZjqpfcnsGiKFd8mjHQKnj5bMrw6fJu0olQ";
	
	@Override
	public int getFetchBlockSize() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int getResultCount() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public List<SearchResult> getResults(int first, int count) {
		// TODO Auto-generated method stub
		return null;
	}

}
